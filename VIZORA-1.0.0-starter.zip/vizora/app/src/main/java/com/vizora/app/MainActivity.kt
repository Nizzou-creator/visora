package com.vizora.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { VizoraApp() } } }

private val Bg = Color(0xFF050714); private val Card = Color(0xFF10152A); private val Purple = Color(0xFF7C3CFF); private val Blue = Color(0xFF26A7FF)

@Composable fun VizoraApp() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var editor by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { selectedVideo = uri; editor = true } }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Purple)) {
        if (editor) EditorScreen(selectedVideo, onBack = { editor = false }, onPick = { picker.launch("video/*") })
        else HomeScreen(onNew = { picker.launch("video/*") }, onTemplates = {})
    }
}

@Composable fun HomeScreen(onNew: () -> Unit, onTemplates: () -> Unit) {
    Scaffold(containerColor = Bg, bottomBar = { NavigationBar(containerColor = Color(0xFF090C1B)) { NavigationBarItem(true, {}, { }, icon={Icon(Icons.Default.Home,null)}, label={Text("الرئيسية")}); NavigationBarItem(false, {}, {}, icon={Icon(Icons.Default.AutoAwesome,null)}, label={Text("القوالب")}); NavigationBarItem(false, {}, {}, icon={Icon(Icons.Default.Folder,null)}, label={Text("مشاريعي")}); NavigationBarItem(false, {}, {}, icon={Icon(Icons.Default.Person,null)}, label={Text("حسابي")}) } }) { p ->
        Column(Modifier.padding(p).padding(horizontal=18.dp).fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Text("VIZORA", fontSize=27.sp, fontWeight=FontWeight.ExtraBold); Surface(color=Color(0xFF201A3E), shape=RoundedCornerShape(20.dp)) { Text("👑 Premium", Modifier.padding(horizontal=14.dp, vertical=8.dp), color=Color(0xFFE5C76A), fontWeight=FontWeight.Bold) } }
            Spacer(Modifier.height(18.dp));
            Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(Color(0xFF18154A), Color(0xFF111B44), Color(0xFF32104A))), RoundedCornerShape(24.dp)).padding(22.dp)) { Column(Modifier.align(Alignment.CenterStart)) { Text("اصنع محتواك باحتراف", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold); Text("أدوات سريعة • قوالب جاهزة • AI", color=Color(0xFFCDD4F2), modifier=Modifier.padding(top=5.dp)); Spacer(Modifier.height(16.dp)); Button(onClick=onNew, colors=ButtonDefaults.buttonColors(containerColor=Purple)) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(6.dp)); Text("ابدأ الآن") } } }
            Spacer(Modifier.height(20.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) { Quick("🎬","تعديل فيديو",onNew); Quick("✨","AI Tools",{}); Quick("▦","القوالب",onTemplates); Quick("📁","مشاريعي",{}) }
            Spacer(Modifier.height(24.dp)); Text("قوالب شائعة", fontSize=19.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.height(12.dp)); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(12.dp)) { Template("TikTok Viral"); Template("Travel Vlog"); Template("Cinematic") }
            Spacer(Modifier.height(22.dp)); Text("صمّم أسرع. انشر أفضل. ✨", color=Color(0xFF8E98BA), modifier=Modifier.padding(bottom=24.dp))
        }
    }
}

@Composable fun Quick(icon:String, title:String, action:()->Unit) { Surface(Modifier.width(82.dp).height(86.dp).clickable { action() }, color=Card, shape=RoundedCornerShape(18.dp)) { Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center, modifier=Modifier.fillMaxSize()) { Text(icon, fontSize=25.sp); Text(title, fontSize=11.sp, modifier=Modifier.padding(top=5.dp)) } } }
@Composable fun Template(name:String) { Surface(Modifier.width(145.dp).height(130.dp), shape=RoundedCornerShape(18.dp), color=Color(0xFF171D35)) { Column(Modifier.padding(12.dp), verticalArrangement=Arrangement.Bottom) { Spacer(Modifier.weight(1f)); Text(name,fontWeight=FontWeight.Bold); Text("قالب جاهز", color=Color(0xFF9CA8CF), fontSize=11.sp) } } }

@Composable fun EditorScreen(uri: Uri?, onBack:()->Unit, onPick:()->Unit) {
    var playing by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { uri?.let { setMediaItem(MediaItem.fromUri(it)); prepare() } } }
    DisposableEffect(player) { onDispose { player.release() } }
    Scaffold(containerColor=Bg, topBar={ TopAppBar(title={Text("محرر VIZORA",fontWeight=FontWeight.Bold)}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}}, actions={TextButton(onClick={}){Text("تصدير",color=Color.White)}}), colors=TopAppBarDefaults.topAppBarColors(containerColor=Bg)) }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            Box(Modifier.fillMaxWidth().height(300.dp).padding(horizontal=12.dp).background(Color.Black,RoundedCornerShape(18.dp))) { AndroidView({ PlayerView(it).apply { this.player=player; useController=false } }, Modifier.fillMaxSize()); IconButton(onClick={ playing=!playing; player.playWhenReady=playing }, modifier=Modifier.align(Alignment.Center).background(Color(0xAA000000), RoundedCornerShape(50))) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow,null,color=Color.White) } }
            Text("00:00 / 00:00", Modifier.align(Alignment.CenterHorizontally).padding(8.dp), color=Color(0xFF9CA8CF))
            Surface(Modifier.fillMaxWidth().height(92.dp).padding(horizontal=12.dp), color=Color(0xFF0D1224), shape=RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).padding(10.dp), verticalAlignment=Alignment.CenterVertically) { repeat(6) { Surface(Modifier.width(76.dp).fillMaxHeight(), color=Color(0xFF1A2140), shape=RoundedCornerShape(8.dp)) {} } } }
            Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.padding(horizontal=12.dp)) { Tool(Icons.Default.ContentCut,"قص"); Tool(Icons.Default.MusicNote,"موسيقى"); Tool(Icons.Default.TextFields,"نص"); Tool(Icons.Default.AutoAwesome,"فلاتر"); Tool(Icons.Default.Timelapse,"السرعة"); Tool(Icons.Default.AddPhotoAlternate,"وسائط") }
            Spacer(Modifier.weight(1f)); Button(onClick=onPick, modifier=Modifier.fillMaxWidth().padding(16.dp).height(54.dp), colors=ButtonDefaults.buttonColors(containerColor=Purple), shape=RoundedCornerShape(16.dp)) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(8.dp)); Text("إضافة فيديو آخر",fontWeight=FontWeight.Bold) }
        }
    }
}
@Composable fun Tool(icon: androidx.compose.ui.graphics.vector.ImageVector, label:String) { Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.width(70.dp)) { Surface(color=Card, shape=RoundedCornerShape(15.dp), modifier=Modifier.size(52.dp)) { Box(contentAlignment=Alignment.Center){Icon(icon,null,color=Color.White)} }; Text(label,fontSize=11.sp,modifier=Modifier.padding(top=5.dp)) } }
